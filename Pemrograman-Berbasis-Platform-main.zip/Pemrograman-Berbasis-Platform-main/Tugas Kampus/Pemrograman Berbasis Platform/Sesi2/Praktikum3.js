let a = 20;
let b = 6;
console.log("Penjumlahan:", a + b);
console.log("Pengurangan:", a - b);
console.log("Perkalian:", a * b);
console.log("Pembagian:", a / b);
console.log("Modulus:", a % b);

console.log("luas persegi: ", a * a);
console.log("luas lingkaran: ", 3.14 * b * b);
console.log("luas segitiga: ", 0.5 * a * b);